import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { page } from "../worker/index.js";

const projectRoot = resolve(fileURLToPath(new URL("..", import.meta.url)));
const clientRoot = resolve(projectRoot, "dist/client");

await mkdir(clientRoot, { recursive: true });
await writeFile(resolve(clientRoot, "index.html"), page, "utf8");
console.log(`Exported ${resolve(clientRoot, "index.html")}`);
