from math import cos, pi
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


WIDTH = 1600
HEIGHT = 1000
MARGIN = 74
PANEL_WIDTH = 390
MAP_RIGHT = WIDTH - PANEL_WIDTH - 34
MAP_BOTTOM = HEIGHT - 68

BOUNDS = {
    "west": 12.8060,
    "east": 12.8270,
    "south": 46.6875,
    "north": 46.6970,
}

PLACES = [
    ("1", "Lesachtalerhof", 46.692644, 12.817880, (-235, -82)),
    ("2", "Ferienwohnungen Wilhelmer", 46.692779, 12.817912, (34, -30)),
    ("3", "Musikhof Lexer", 46.693270, 12.816790, (-218, -72)),
    ("4", "Haus Anita", 46.689733, 12.822627, (-180, 42)),
    ("5", "Gaestehaus Ortner", 46.690926, 12.819896, (34, 24)),
    ("6", "Haus Lanzinger", 46.691570, 12.819150, (-204, 48)),
]

QUEUED = [
    "Kultursaal Apartment - Liesing 15",
    "Haus Obernosterer - Liesing 25",
    "Kleines Berghotel - Klebas 7",
]


def font(size, bold=False):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        if bold
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"
        if bold
        else "/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf",
    ]
    for candidate in candidates:
        if Path(candidate).exists():
            return ImageFont.truetype(candidate, size)
    return ImageFont.load_default()


def project(lat, lon):
    x = MARGIN + (lon - BOUNDS["west"]) / (BOUNDS["east"] - BOUNDS["west"]) * (
        MAP_RIGHT - MARGIN
    )
    y = MARGIN + (BOUNDS["north"] - lat) / (
        BOUNDS["north"] - BOUNDS["south"]
    ) * (MAP_BOTTOM - MARGIN)
    return x, y


def rounded_label(draw, xy, text, text_font, fill, outline, text_fill):
    x, y = xy
    box = draw.textbbox((0, 0), text, font=text_font)
    width = box[2] - box[0] + 20
    height = box[3] - box[1] + 14
    draw.rounded_rectangle(
        (x, y, x + width, y + height),
        radius=5,
        fill=fill,
        outline=outline,
        width=1,
    )
    draw.text((x + 10, y + 6), text, font=text_font, fill=text_fill)
    return width, height


image = Image.new("RGB", (WIDTH, HEIGHT), "#f5f4ec")
draw = ImageDraw.Draw(image)

title_font = font(30, bold=True)
subtitle_font = font(16)
label_font = font(16, bold=True)
small_font = font(13)
small_bold = font(13, bold=True)
number_font = font(14, bold=True)
panel_title_font = font(18, bold=True)

draw.text((MARGIN, 24), "Liesing lodging map", font=title_font, fill="#20231f")
draw.text(
    (MARGIN, 59),
    "Self-contained extent preview - verified coordinates only",
    font=subtitle_font,
    fill="#686d65",
)

draw.rectangle(
    (MARGIN, MARGIN + 18, MAP_RIGHT, MAP_BOTTOM),
    fill="#ebece5",
    outline="#aeb2aa",
    width=2,
)

# Geographic grid, deliberately not a fabricated street layer.
for lon in (12.808, 12.812, 12.816, 12.820, 12.824):
    x, _ = project(BOUNDS["south"], lon)
    draw.line((x, MARGIN + 18, x, MAP_BOTTOM), fill="#d0d3cb", width=1)
    draw.text((x - 32, MAP_BOTTOM + 9), f"{lon:.3f} E", font=small_font, fill="#73786f")

for lat in (46.689, 46.691, 46.693, 46.695):
    _, y = project(lat, BOUNDS["west"])
    draw.line((MARGIN, y, MAP_RIGHT, y), fill="#d0d3cb", width=1)
    draw.text((10, y - 8), f"{lat:.3f} N", font=small_font, fill="#73786f")

# Pins and callouts use only independently verified coordinates.
for number, name, lat, lon, offset in PLACES:
    x, y = project(lat, lon)
    label_x = x + offset[0]
    label_y = y + offset[1]
    label_width, label_height = rounded_label(
        draw,
        (label_x, label_y),
        name,
        label_font,
        "#fffffb",
        "#b9bcb4",
        "#252822",
    )
    anchor_x = label_x + (label_width if offset[0] < 0 else 0)
    anchor_y = label_y + label_height / 2
    draw.line((x, y, anchor_x, anchor_y), fill="#81867d", width=2)
    draw.ellipse((x - 15, y - 15, x + 15, y + 15), fill="#b53b2f", outline="#ffffff", width=3)
    number_box = draw.textbbox((0, 0), number, font=number_font)
    draw.text(
        (x - (number_box[2] - number_box[0]) / 2, y - 9),
        number,
        font=number_font,
        fill="#ffffff",
    )

# Scale bar based on the geographic extent at this latitude.
meters_per_lon_degree = 111320 * cos(46.692 * pi / 180)
map_width_m = (BOUNDS["east"] - BOUNDS["west"]) * meters_per_lon_degree
map_width_px = MAP_RIGHT - MARGIN
scale_px = 500 / map_width_m * map_width_px
scale_x = MARGIN + 28
scale_y = MAP_BOTTOM - 30
draw.line((scale_x, scale_y, scale_x + scale_px, scale_y), fill="#30342e", width=3)
draw.line((scale_x, scale_y - 7, scale_x, scale_y + 7), fill="#30342e", width=2)
draw.line(
    (scale_x + scale_px, scale_y - 7, scale_x + scale_px, scale_y + 7),
    fill="#30342e",
    width=2,
)
draw.text((scale_x, scale_y - 27), "500 m", font=small_bold, fill="#30342e")

# North arrow.
north_x = MAP_RIGHT - 42
north_y = MARGIN + 42
draw.text((north_x - 5, north_y - 34), "N", font=small_bold, fill="#30342e")
draw.polygon(
    [(north_x, north_y - 10), (north_x - 9, north_y + 22), (north_x, north_y + 15), (north_x + 9, north_y + 22)],
    fill="#30342e",
)

# Side panel states exactly what is and is not represented.
panel_left = MAP_RIGHT + 24
draw.rounded_rectangle(
    (panel_left, MARGIN + 18, WIDTH - 28, MAP_BOTTOM),
    radius=6,
    fill="#fffffb",
    outline="#c6c8c0",
    width=1,
)
draw.text((panel_left + 24, MARGIN + 44), "Current map state", font=panel_title_font, fill="#20231f")
draw.text((panel_left + 24, MARGIN + 82), "Verified coordinate pins", font=small_bold, fill="#62675f")

cursor_y = MARGIN + 114
for number, name, _, _, _ in PLACES:
    draw.ellipse(
        (panel_left + 24, cursor_y - 2, panel_left + 46, cursor_y + 20),
        fill="#b53b2f",
    )
    draw.text((panel_left + 31, cursor_y + 1), number, font=small_bold, fill="#ffffff")
    draw.text((panel_left + 58, cursor_y), name, font=small_font, fill="#30342e")
    cursor_y += 38

cursor_y += 20
draw.line((panel_left + 24, cursor_y, WIDTH - 52, cursor_y), fill="#d7d8d2", width=1)
cursor_y += 25
draw.text((panel_left + 24, cursor_y), "Accepted addresses", font=small_bold, fill="#62675f")
cursor_y += 34
for item in QUEUED:
    draw.ellipse((panel_left + 26, cursor_y + 6, panel_left + 32, cursor_y + 12), fill="#969a92")
    draw.multiline_text((panel_left + 43, cursor_y), item, font=small_font, fill="#30342e", spacing=4)
    cursor_y += 48

cursor_y += 12
draw.line((panel_left + 24, cursor_y, WIDTH - 52, cursor_y), fill="#d7d8d2", width=1)
cursor_y += 24
draw.multiline_text(
    (panel_left + 24, cursor_y),
    "Roads and buildings are intentionally\nabsent here. The sandbox blocked\nretrieval of the OSM geometry; none\nhas been guessed.",
    font=small_font,
    fill="#6c7169",
    spacing=7,
)

draw.text(
    (MARGIN, HEIGHT - 34),
    "Geographic positions shown in WGS84. This preview establishes extent and label behavior; it is not yet the OSM basemap.",
    font=small_font,
    fill="#686d65",
)

output_dir = Path(__file__).resolve().parents[1] / "dist" / "client"
output_dir.mkdir(parents=True, exist_ok=True)
image.save(output_dir / "liesing-map-preview.png", optimize=True)
print(output_dir / "liesing-map-preview.png")
