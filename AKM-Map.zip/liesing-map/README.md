# Liesing Lodging Map

A schematic lodging map for AlpenKammerMusik in Liesing and Klebas, Lesachtal, Austria.

The goal is a readable map showing local roads, paths, buildings, and lodging pins using OpenStreetMap data. The finished artifact should be self-contained so it can be previewed, printed, or shared without relying on live map tiles.

## Current Status

The repository currently contains:

- An interactive HTML prototype using live OpenStreetMap raster tiles.
- Pan, zoom, reset, scale, north arrow, attribution, and pin visibility controls.
- Six lodging pins with independently sourced coordinates.
- A self-contained PNG showing the map extent and coordinate relationships.
- A Cloudflare Worker/Sites wrapper for eventual hosting.

The live tiles did not render inside the ChatGPT artifact sandbox because external tile requests and the localhost preview server were isolated. This is an environment limitation, not necessarily a problem with the HTML. Preview the interactive version on a normal laptop browser.

The self-contained PNG is deliberately **not** presented as a basemap: it contains verified coordinates but no roads or buildings. No geographic features have been guessed.

## Quick Preview

From this directory:

```sh
bash scripts/build.sh
python3 -m http.server 4173 -d dist/client
```

Then open:

```text
http://localhost:4173
```

The interactive page loads standard OpenStreetMap tiles from `tile.openstreetmap.org`, so the browser needs internet access.

You can also open `dist/client/index.html` directly, although using the local HTTP server is more reliable.

## Fetch the OSM Basemap Data

The recommended next step is to download the raw OSM XML for the small project area:

```sh
mkdir -p data
curl -L \
  'https://api.openstreetmap.org/api/0.6/map?bbox=12.804,46.687,12.828,46.698' \
  -o data/liesing.osm
```

The bounding box covers Liesing, Klebas, Haus Anita to the east, and the currently identified lodging area:

```text
west   12.804
south  46.687
east   12.828
north  46.698
```

OpenStreetMap's browser export page can be used instead if the API download fails:

```text
https://www.openstreetmap.org/export#map=16/46.6925/12.8160
```

Save the resulting XML as `data/liesing.osm`.

## Recommended Implementation

Once `data/liesing.osm` exists:

1. Parse nodes and ways from the XML.
2. Retain the useful local features:
   - `highway=*` roads and paths
   - `building=*` footprints
   - `waterway=*`
   - relevant `landuse=*`, `natural=*`, and place labels
3. Project latitude/longitude into a local planar coordinate system.
4. Render the geometry as an embedded SVG beneath the pin layer.
5. Keep the result self-contained; do not require remote tiles in the final deliverable.
6. Export matching SVG, PNG, and PDF versions after the layout is settled.

Python's standard `xml.etree.ElementTree` is sufficient for this small extract. A GeoJSON conversion is optional; direct OSM XML to SVG will keep dependencies minimal.

## Location Data

### Coordinates currently plotted

| # | Place | Address | Latitude | Longitude |
|---:|---|---|---:|---:|
| 1 | Lesachtalerhof | Liesing 40 | 46.692644 | 12.817880 |
| 2 | Ferienwohnungen Wilhelmer | Liesing 51 | 46.692779 | 12.817912 |
| 3 | Musikhof Lexer | Liesing 11 | 46.693270 | 12.816790 |
| 4 | Haus Anita | Liesing 47 | 46.689733 | 12.822627 |
| 5 | Gaestehaus Ortner | Liesing 8 | 46.690926 | 12.819896 |
| 6 | Haus Lanzinger | Liesing 21 | 46.691570 | 12.819150 |

The Lesachtalerhof and Wilhelmer coordinates nearly overlap despite having different street numbers. Treat those coordinates as provisional third-party geocodes and anchor both to their actual OSM address/building features before finalizing the map.

### Accepted addresses awaiting precise OSM anchors

| Place label | Accepted location |
|---|---|
| Kultursaal Apartment | Volksmusikakademie/Kultursaal, Liesing 15 |
| Obermosterer AirBNB | Haus Obernosterer, Liesing 25 |
| Obermosterer Apartment | Haus Obernosterer, Liesing 25 |
| Kleines Berghotel | Klebas 7 |

`Obermosterer` appears to be an internal misspelling or variant of `Obernosterer`. The two lodging labels are expected to share one building unless later information shows otherwise.

### Deliberately omitted for now

- Haus Simona
- Haus Salcher

No credible local address was found for either. Do not place them without an address or map pin from the user.

## Design Direction

- Cover Liesing and Klebas while retaining readable individual buildings.
- Keep the basemap quiet and schematic rather than using full-color consumer-map styling.
- Emphasize lodging pins and walking orientation.
- Preserve a north arrow, scale, and OpenStreetMap attribution.
- Avoid label collisions, especially around Liesing 40/51.
- Do not move pins merely to make the layout prettier; use leader lines when labels need displacement.
- Keep the final printable version legible at ordinary paper size.

## Project Structure

```text
liesing-map/
├── .openai/hosting.json
├── data/                         # create locally; raw OSM extract goes here
├── dist/                         # generated output; rebuilt by build.sh
│   ├── client/
│   │   ├── index.html
│   │   └── liesing-map-preview.png
│   └── server/index.js
├── scripts/
│   ├── build.sh
│   ├── export-html.mjs
│   ├── render_preview.py
│   └── validate-artifact.mjs
└── worker/index.js               # edit this, not dist/server/index.js
```

## Build and Validation

```sh
bash scripts/build.sh
node scripts/validate-artifact.mjs
```

`scripts/build.sh` regenerates `dist/`, including the standalone HTML and coordinate preview. Do not manually edit generated files under `dist/`.

## OpenStreetMap Attribution

The final map must visibly include:

```text
© OpenStreetMap contributors
```

See the OpenStreetMap copyright and ODbL guidance before distributing modified map data or rendered products:

```text
https://www.openstreetmap.org/copyright
```
