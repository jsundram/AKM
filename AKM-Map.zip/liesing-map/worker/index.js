export const page = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title>Liesing Lodging Map</title>
    <style>
      :root {
        color-scheme: light;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        color: #20231f;
        background: #e8e8e2;
      }

      * { box-sizing: border-box; }

      html, body { height: 100%; margin: 0; overflow: hidden; }
      body { background: #e8e8e2; }

      .shell {
        display: grid;
        grid-template-rows: 58px minmax(0, 1fr);
        height: 100%;
      }

      header {
        z-index: 20;
        display: flex;
        align-items: center;
        justify-content: space-between;
        min-width: 0;
        padding: 0 18px;
        border-bottom: 1px solid #c9cbc3;
        background: rgba(249, 249, 245, .97);
      }

      .identity { min-width: 0; }
      h1 { margin: 0; font-size: 16px; font-weight: 720; letter-spacing: 0; }
      .subtitle { margin-top: 2px; color: #6b7068; font-size: 11px; white-space: nowrap; }

      .header-actions { display: flex; align-items: center; gap: 8px; }

      button {
        color: inherit;
        font: inherit;
      }

      .toggle {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        height: 32px;
        padding: 0 10px;
        border: 1px solid #c7c9c1;
        border-radius: 6px;
        background: #fff;
        cursor: pointer;
        font-size: 12px;
        font-weight: 650;
      }

      .toggle[aria-pressed="false"] { color: #747970; background: #f2f2ee; }

      .toggle-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #b53b2f;
        box-shadow: 0 0 0 2px #f2d7d2;
      }

      .toggle[aria-pressed="false"] .toggle-dot { background: #9a9d96; box-shadow: none; }

      #map {
        position: relative;
        min-height: 0;
        overflow: hidden;
        background: #dfe3db;
        cursor: grab;
        touch-action: none;
      }

      #map.dragging { cursor: grabbing; }

      .tile-pane, .marker-pane {
        position: absolute;
        inset: 0;
      }

      .tile-pane { z-index: 1; }

      .tile-pane img {
        position: absolute;
        width: 256px;
        height: 256px;
        user-select: none;
        -webkit-user-drag: none;
        filter: grayscale(.72) saturate(.48) sepia(.08) brightness(1.035) contrast(.94);
      }

      .map-wash {
        position: absolute;
        z-index: 2;
        inset: 0;
        pointer-events: none;
        background: rgba(246, 245, 237, .08);
        mix-blend-mode: screen;
      }

      .marker-pane { z-index: 5; pointer-events: none; }
      .marker-pane.hidden { display: none; }

      .marker {
        position: absolute;
        display: flex;
        align-items: center;
        transform: translate(-11px, -11px);
        white-space: nowrap;
      }

      .pin {
        display: grid;
        flex: 0 0 auto;
        width: 22px;
        height: 22px;
        place-items: center;
        border: 2px solid #fff;
        border-radius: 50%;
        color: #fff;
        background: #b53b2f;
        box-shadow: 0 1px 4px rgba(28, 31, 27, .34);
        font-size: 10px;
        font-weight: 800;
      }

      .marker-label {
        margin-left: 6px;
        padding: 3px 5px 4px;
        border: 1px solid rgba(117, 119, 111, .42);
        border-radius: 4px;
        color: #252822;
        background: rgba(255, 255, 252, .92);
        box-shadow: 0 1px 2px rgba(28, 31, 27, .1);
        font-size: 11px;
        font-weight: 700;
        line-height: 1;
      }

      .marker.reverse { flex-direction: row-reverse; transform: translate(calc(-100% + 11px), -11px); }
      .marker.reverse .marker-label { margin-right: 6px; margin-left: 0; }

      .map-controls {
        position: absolute;
        z-index: 10;
        top: 14px;
        right: 14px;
        display: grid;
        overflow: hidden;
        border: 1px solid #bbbdb5;
        border-radius: 6px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(38, 42, 36, .16);
      }

      .map-controls button {
        display: grid;
        width: 36px;
        height: 36px;
        padding: 0;
        place-items: center;
        border: 0;
        background: #fff;
        cursor: pointer;
        font-size: 20px;
        line-height: 1;
      }

      .map-controls button + button { border-top: 1px solid #d3d4ce; }
      .map-controls button:hover { background: #f2f2ed; }

      .north {
        position: absolute;
        z-index: 10;
        top: 15px;
        left: 15px;
        display: grid;
        width: 34px;
        height: 48px;
        place-items: center;
        color: #30342e;
        filter: drop-shadow(0 1px 1px rgba(255,255,255,.9));
        pointer-events: none;
      }

      .north b { font-size: 11px; }
      .north i {
        width: 0;
        height: 0;
        margin-top: -2px;
        border-right: 6px solid transparent;
        border-bottom: 21px solid #30342e;
        border-left: 6px solid transparent;
      }

      .map-meta {
        position: absolute;
        z-index: 10;
        right: 12px;
        bottom: 10px;
        display: flex;
        align-items: flex-end;
        gap: 12px;
        color: #484d45;
        font-size: 10px;
        line-height: 1.2;
        text-shadow: 0 1px 0 rgba(255,255,255,.9);
      }

      .scale { display: grid; gap: 3px; justify-items: end; }
      .scale-line { height: 5px; border: solid #444940; border-width: 0 1px 1px; }
      .attribution a { color: inherit; }

      .status {
        position: absolute;
        z-index: 10;
        bottom: 12px;
        left: 14px;
        max-width: calc(100% - 260px);
        padding: 6px 8px;
        border: 1px solid rgba(179, 181, 172, .78);
        border-radius: 5px;
        color: #52574f;
        background: rgba(251, 251, 247, .9);
        font-size: 10px;
        box-shadow: 0 1px 3px rgba(38, 42, 36, .1);
      }

      @media (max-width: 640px) {
        .shell { grid-template-rows: 54px minmax(0, 1fr); }
        header { padding: 0 12px; }
        h1 { font-size: 14px; }
        .subtitle { display: none; }
        .toggle { height: 30px; padding: 0 9px; }
        .status { right: 12px; bottom: 38px; max-width: none; }
        .map-meta { right: 10px; bottom: 8px; left: 12px; justify-content: space-between; }
        .marker-label { font-size: 10px; }
      }

      @media print {
        .shell { display: block; height: 100vh; }
        header { height: 52px; }
        #map { height: calc(100vh - 52px); }
        .header-actions, .map-controls, .status { display: none; }
      }
    </style>
  </head>
  <body>
    <div class="shell">
      <header>
        <div class="identity">
          <h1>Liesing lodging map</h1>
          <div class="subtitle">Working basemap · Liesing and Klebas · Lesachtal, Carinthia</div>
        </div>
        <div class="header-actions">
          <button class="toggle" id="pin-toggle" type="button" aria-pressed="true">
            <span class="toggle-dot" aria-hidden="true"></span>
            Pins
          </button>
        </div>
      </header>

      <main id="map" aria-label="Interactive OpenStreetMap of Liesing and Klebas">
        <div class="tile-pane" aria-hidden="true"></div>
        <div class="map-wash" aria-hidden="true"></div>
        <div class="marker-pane" aria-hidden="true"></div>

        <div class="north" aria-hidden="true"><b>N</b><i></i></div>

        <div class="map-controls" aria-label="Map controls">
          <button id="zoom-in" type="button" title="Zoom in" aria-label="Zoom in">+</button>
          <button id="zoom-out" type="button" title="Zoom out" aria-label="Zoom out">−</button>
          <button id="reset" type="button" title="Reset map" aria-label="Reset map" style="font-size:15px">⌂</button>
        </div>

        <div class="status">6 verified coordinates shown · accepted addresses at Liesing 15 and 25 will be anchored next</div>

        <div class="map-meta">
          <div class="attribution">Map data © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap contributors</a></div>
          <div class="scale"><span id="scale-label">200 m</span><span class="scale-line" id="scale-line"></span></div>
        </div>
      </main>
    </div>

    <script>
      (function () {
        var map = document.getElementById("map");
        var tilePane = map.querySelector(".tile-pane");
        var markerPane = map.querySelector(".marker-pane");
        var scaleLabel = document.getElementById("scale-label");
        var scaleLine = document.getElementById("scale-line");
        var tileSize = 256;
        var minZoom = 14;
        var maxZoom = 18;
        var initial = { lat: 46.69215, lon: 12.81655, zoom: window.innerWidth < 640 ? 15 : 16 };
        var state = { lat: initial.lat, lon: initial.lon, zoom: initial.zoom };
        var drag = null;
        var frame = 0;

        var places = [
          { n: 1, name: "Lesachtalerhof", lat: 46.692644, lon: 12.817880, reverse: true },
          { n: 2, name: "Ferienwohnungen Wilhelmer", lat: 46.692779, lon: 12.817912 },
          { n: 3, name: "Musikhof Lexer", lat: 46.693270, lon: 12.816790, reverse: true },
          { n: 4, name: "Haus Anita", lat: 46.689733, lon: 12.822627, reverse: true },
          { n: 5, name: "Gästehaus Ortner", lat: 46.690926, lon: 12.819896 },
          { n: 6, name: "Haus Lanzinger", lat: 46.691570, lon: 12.819150, reverse: true }
        ];

        function clamp(value, low, high) { return Math.max(low, Math.min(high, value)); }

        function project(lat, lon, zoom) {
          var size = tileSize * Math.pow(2, zoom);
          var sin = Math.sin(lat * Math.PI / 180);
          sin = clamp(sin, -0.9999, 0.9999);
          return {
            x: (lon + 180) / 360 * size,
            y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * size
          };
        }

        function unproject(x, y, zoom) {
          var size = tileSize * Math.pow(2, zoom);
          var lon = x / size * 360 - 180;
          var n = Math.PI - 2 * Math.PI * y / size;
          var lat = 180 / Math.PI * Math.atan(Math.sinh(n));
          return { lat: lat, lon: lon };
        }

        function geometry() {
          var center = project(state.lat, state.lon, state.zoom);
          return {
            center: center,
            left: center.x - map.clientWidth / 2,
            top: center.y - map.clientHeight / 2
          };
        }

        function scheduleRender() {
          if (frame) return;
          frame = requestAnimationFrame(function () {
            frame = 0;
            render();
          });
        }

        function renderTiles(g) {
          var startX = Math.floor(g.left / tileSize);
          var endX = Math.floor((g.left + map.clientWidth) / tileSize);
          var startY = Math.floor(g.top / tileSize);
          var endY = Math.floor((g.top + map.clientHeight) / tileSize);
          var count = Math.pow(2, state.zoom);
          var fragment = document.createDocumentFragment();

          tilePane.replaceChildren();
          for (var x = startX; x <= endX; x += 1) {
            for (var y = startY; y <= endY; y += 1) {
              if (y < 0 || y >= count) continue;
              var wrappedX = ((x % count) + count) % count;
              var image = new Image();
              image.alt = "";
              image.draggable = false;
              image.src = "https://tile.openstreetmap.org/" + state.zoom + "/" + wrappedX + "/" + y + ".png";
              image.style.left = Math.round(x * tileSize - g.left) + "px";
              image.style.top = Math.round(y * tileSize - g.top) + "px";
              fragment.appendChild(image);
            }
          }
          tilePane.appendChild(fragment);
        }

        function renderMarkers(g) {
          var fragment = document.createDocumentFragment();
          markerPane.replaceChildren();

          places.forEach(function (place) {
            var point = project(place.lat, place.lon, state.zoom);
            var marker = document.createElement("div");
            marker.className = "marker" + (place.reverse ? " reverse" : "");
            marker.style.left = (point.x - g.left) + "px";
            marker.style.top = (point.y - g.top) + "px";

            var pin = document.createElement("span");
            pin.className = "pin";
            pin.textContent = place.n;

            var label = document.createElement("span");
            label.className = "marker-label";
            label.textContent = place.name;

            marker.append(pin, label);
            fragment.appendChild(marker);
          });

          markerPane.appendChild(fragment);
        }

        function niceDistance(maxMeters) {
          var power = Math.pow(10, Math.floor(Math.log10(maxMeters)));
          var value = maxMeters / power;
          if (value >= 5) return 5 * power;
          if (value >= 2) return 2 * power;
          return power;
        }

        function renderScale() {
          var metersPerPixel = Math.cos(state.lat * Math.PI / 180) * 2 * Math.PI * 6378137 / (tileSize * Math.pow(2, state.zoom));
          var meters = niceDistance(112 * metersPerPixel);
          var width = meters / metersPerPixel;
          scaleLine.style.width = Math.round(width) + "px";
          scaleLabel.textContent = meters >= 1000 ? (meters / 1000) + " km" : meters + " m";
        }

        function render() {
          var g = geometry();
          renderTiles(g);
          renderMarkers(g);
          renderScale();
        }

        function setZoom(nextZoom, anchorX, anchorY) {
          nextZoom = clamp(nextZoom, minZoom, maxZoom);
          if (nextZoom === state.zoom) return;

          var old = geometry();
          var x = anchorX == null ? map.clientWidth / 2 : anchorX;
          var y = anchorY == null ? map.clientHeight / 2 : anchorY;
          var anchor = unproject(old.left + x, old.top + y, state.zoom);
          state.zoom = nextZoom;
          var anchorWorld = project(anchor.lat, anchor.lon, state.zoom);
          var centerWorld = {
            x: anchorWorld.x - x + map.clientWidth / 2,
            y: anchorWorld.y - y + map.clientHeight / 2
          };
          var center = unproject(centerWorld.x, centerWorld.y, state.zoom);
          state.lat = center.lat;
          state.lon = center.lon;
          render();
        }

        map.addEventListener("pointerdown", function (event) {
          if (event.button !== 0) return;
          map.setPointerCapture(event.pointerId);
          drag = {
            x: event.clientX,
            y: event.clientY,
            center: project(state.lat, state.lon, state.zoom)
          };
          map.classList.add("dragging");
        });

        map.addEventListener("pointermove", function (event) {
          if (!drag) return;
          var moved = unproject(
            drag.center.x - (event.clientX - drag.x),
            drag.center.y - (event.clientY - drag.y),
            state.zoom
          );
          state.lat = moved.lat;
          state.lon = moved.lon;
          scheduleRender();
        });

        function endDrag() {
          drag = null;
          map.classList.remove("dragging");
        }

        map.addEventListener("pointerup", endDrag);
        map.addEventListener("pointercancel", endDrag);

        map.addEventListener("wheel", function (event) {
          event.preventDefault();
          var rect = map.getBoundingClientRect();
          setZoom(state.zoom + (event.deltaY < 0 ? 1 : -1), event.clientX - rect.left, event.clientY - rect.top);
        }, { passive: false });

        document.getElementById("zoom-in").addEventListener("click", function () { setZoom(state.zoom + 1); });
        document.getElementById("zoom-out").addEventListener("click", function () { setZoom(state.zoom - 1); });
        document.getElementById("reset").addEventListener("click", function () {
          state.lat = initial.lat;
          state.lon = initial.lon;
          state.zoom = window.innerWidth < 640 ? 15 : 16;
          render();
        });

        document.getElementById("pin-toggle").addEventListener("click", function (event) {
          var button = event.currentTarget;
          var visible = button.getAttribute("aria-pressed") === "true";
          button.setAttribute("aria-pressed", String(!visible));
          markerPane.classList.toggle("hidden", visible);
        });

        new ResizeObserver(scheduleRender).observe(map);
        render();
      }());
    </script>
  </body>
</html>`;

export default {
  async fetch(request, env, ctx) {
    void env;
    void ctx;

    if (new URL(request.url).pathname !== "/") {
      return new Response("Not found", { status: 404 });
    }

    return new Response(page, {
      headers: {
        "content-type": "text/html; charset=utf-8",
        "cache-control": "public, max-age=300"
      }
    });
  }
};
